package br.com.birda.gasagua;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 7001;
    private WebView webView;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(13, 71, 161));
        getWindow().setNavigationBarColor(Color.rgb(13, 71, 161));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Visual-only polish inside this app; live Netlify and Firebase remain untouched.
                String script = "(()=>{if(document.getElementById('birda-app-polish'))return;" +
                    "const s=document.createElement('style');s.id='birda-app-polish';" +
                    "s.textContent=`html{scroll-behavior:smooth}body{font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif!important;background:#f2f5fa!important;color:#172033!important}" +
                    "header{background:linear-gradient(135deg,#0d47a1,#1976d2)!important;padding:20px 18px!important;box-shadow:0 5px 18px #0d47a140!important;border-bottom:3px solid #90caf9!important}" +
                    "header h1{font-size:23px!important;letter-spacing:-.4px;display:flex;align-items:center;gap:10px}header h1:before{content:'';display:inline-block;flex:0 0 30px;width:30px;height:40px;background-image:url(data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBAUEBAYFBQUGBgYHCQ4JCQgICRINDQoOFRIWFhUSFBQXGiEcFxgfGRQUHScdHyIjJSUlFhwpLCgkKyEkJST/2wBDAQYGBgkICREJCREkGBQYJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCT/wAARCACjAHgDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAABwAEBQYIAwIB/8QATBAAAQMDAgMDBwgDCw0AAAAAAQIDBAAFEQYhBxIxE0FRCBQiMmFxkUJSgaGxssHRFSPCM1NiZHJ0goOSk7MWJCUmNDVDRFRzoqPS/8QAGgEAAgMBAQAAAAAAAAAAAAAAAwUCBAYBAP/EADMRAAEDAgQCCAUFAQEAAAAAAAEAAgMEEQUSITETUQYiQXGBkaHRMjRhweEUIzNCsSTw/9oADAMBAAIRAxEAPwDTyRXQCvKRXQCpkqAX0CuEu4Q7enmlyWWB3c6gCfcOpodccuI0/QdjjtWlITOnlYS+QD2KU4yQD37/AEUC7PqO731Tjs+4SXlqI5iVn0vf407w3A31jOKXWb6pViGLNpTlDblajf1rZ2R6L3aDxylA+KyKYzOIluhtlxbsFKcZHPLBJ+hCVVmq96sgaVWgz4spQX6iuz9FeOuFHrTZ/iZdNWICbNp3tGR6KVJKlk49w/Crz8FpYnBrn35qizFaqRmdrbckeZ/Hezw8+kwoj5ocV+yKh3vKTtbJI82CvchdA9enNfXVeW9NTceKYbx/Zr0eFXECSnm/QU8ewwHBn4gVJ1Jh7NAL+KGJsQebl1u4fgo1o8p6xDHaNNJ8QQ6PsQaex/KW0s6BnsiT3B4p++gVnmTwg4gjcaaubg8RDWKi5XDjWkLeRpi5pHtiuD8KrOpKRx6oHn+VbbLUgdZx8h7LV8fj9pJ4J5kXDCu9loPD/wACT9VWe1cQtL3hKTGu7KCromSlTCifDCwN6wupmVZXE/pG3yYaubqtsijBw51JbrpcoMWHcu1dU6lKmeYkqRg8wKTkEeOdqg/C4S27TYorK+Vps4XC1UCCAQcg7g0jQMb1vO0fxYt+noQT+h5/ZtuxBnkQtfy0Dog57k4B8M70dKUVVI+nLc2zhcJjBUNmvl7NF5IpV9NKqyOvCRXsV8Ar0K4V4IE+VG0XYlkSEkk9tv3D1aEOkFHs1fQK0vxyt8ebw0uzrzDbjsZKHGVqGS2rnSMg9xwSKzPpIgNL7sEVvejUuemLOR/KyHSBmWTNzt7L5xXCXYVoSoAo/W7HxyKntD8aLzoDTkG0W23W5cVLYX6SMKUpW5KiMEnfvJqv8USDCtIG/wC6n6xTyDwZ17eLHDulss7UuHLjocYU3LbCikjbKVEEe6pVQps5FTa3ZddouOY28FEBryqbm2jMnTkVZ7+zeUPtJqdZ8oS8OwE3A6RjtRSQO0fuKG9yMjY77jfpQfb4Payiy2F32yS7Xaw4nzuapTSksN53Vss5onNQrHZtIG02+SzM7JxlxUlTKQp1shXLnrnCkqrK43W4fRtHBYHOP1P2K0WGUlXUE8VxA7gvk/ynblbloQ9pSO2XElbZ88C0rTnGQU+0V0t/lFX28NKXHs0RjlzsVEn7fwqg3e4X3XyDpW2aXmLlsKTJS8htOJKQMZ58AAb5wT3VJ6b4S8Q4LDiVaXKS4MfrZrCANu/0ifqq9hL6CenEtSwNdyufPdVMTZWQy5KdxcO4eyitW8fdWXht2K63bGmVAoKVMJeyOnyk1X+CEZqLxPjJaASktOnKRgek3nHuyagNdaeuei78/Z7r5uJrKUrWll3tEp5xzAZwN8Gp7gkQ5xHg/wA2UVe/kFOZ4aZsIdA0AfTuVQGW/wC4dURr6FPcf7acEpakRRt7k/ia0ye+gzoiLHl8eNQOvsturjW9C2StOS2rKBzDwOCRn20Z6zWMSZnRs5NHqLplhzLNc7mSvNKvtKlCYr4BX2lSJCUkqIAG5J7q4vKmcZRnhlfR0y0j/ERWWdOq9RDY5iUJyEjv7xWieJWudPXm2yNMsSnpa31pS8IiO0OEqCuUe8gUP7Pw3vbYXIhIk22OvouX2bIx7k5NbXAHfpYXGbq3Ol9Flcb/AOh4bFrbe2qGnEdl9TFqyy6CUOHBQfnYowaI42Ks2kbNZoml5slyDCbYckPvoZZKkpwSMBRIz7M+yvZ4bolNhE24MTOUg4aQ66R44VkYqSbtN607bvM7NdbhGjBRIQI7YCc/yskUSsFNVHrG5vtqB52KFSSVFO2wbYc9CfK4UZduL2pb9DkW9zSFtkw5SFNOtBT73Og7EZSlNRcZF1YsnmELTEltHaJ5EqgrVhsA4TkjO2cd/wAc07uF61UwChzVFwBGxAUE/dAquy9SahQSF6luZz39sr86BLgFPO0AsbbvJ+yKzHZ4SesfID7qxaU1BrDSCXCm1NIbcQltQlQ5IB5ScE8jZOcEgAHGKvzPGK0NNoTOksMOqSOYKYkNpSrG+5RnGe/FAuRqvVh/cr/el+HI6v8AA0zc4k62iYSdSXRPL++q5vvZrp6PRhuVoA8T7FSbjr3uzOPp+VC8bYUq+a2ud/ZfgPw57iezcjS0vJQEoSn0sbj1e8CprQvmCuPchu1FCoKi8mN2Y2KA0OXH0Coa8ax1Df20s3C5KlIBzuy2lRPtUEg/XSsVvvbT3n1stbsh9OcLSklfvHfn2jerv6AiIAm1hb6KJr7uta9/NHvQCSOOeqCQQDbW8Z97dGOst6B1wjRuoTcb9DujFwkJ7F56cSUlHzc4yOg336Vo3T2qbZqaKl+BIQskc3JzAnHiCNiPdWZximkbIH26tgL9wsnGGzscwtvrc6KWpV9pUlTJKgRxr4lPuzHNM2qQpmM2rklvNH0nFd6B7BsD7aOE+T5nBkSevYtLc+AJ/CsULVIuLs24yXyXUuKJHXJO5+2tD0epY5ZjJJqG/wCpPjU72RBke5RJ0dqBVoaLFrhRGFqAy+4nndPtz0FFGyhF0CJFwcVKWj5x2B9g6VnSzXV1tScYor6Yu8rzHCnTjwG1aTE6IFudmh59qzeH1Za7I/UDs7ES7lqe3WaMSlnBAOAO+hbqXiI7LWoF0JQdgkHFRWrrg+sEdocdNzQ4nyHHFEKVQ8PwmKMcR2pRK3E5JHcNugU/c9UBRKuYE+w1XJl9U4SSob91RclxRzk1GvrPjvTF7wzZVY4M+riptvVMyGD5tNfZP8BwivEjXF3fb7J25POoHyXCFD66q7yz1zTZxwjoaXS1JveyYxUjVMO3RTqsr5CfEDH2VM2DV061SWizJWlpJyRnP1HaqT2qvGnUV9QWMdaG2qLtHIz6UNFwtS6N4iW3VLYhXdqPJbICeV1IUD9Bp1f9CL0bzap0U+thpn9dIgBR7NaRupSPmkD6vhQg0g4RJYISgEEHPLWhrXKeesJBc5fRxg7jHhv7Ko1bOA4Oj2O47CjUr+M0tfuNj2qyaH1bF1rp2PdoxAK/RcQPkLHUUqFvk8zPNr9qmyMrKorTiXmwRjlPMUn8KVZ3EacQVDo27dninlFMZoWvO6MV/OLDcj/FXfuGsZxgDEum4/ddvgK2XqH/AHBc/wCaPfcNYzjqCYVz7z2n7Ip30c/v3hLMa/r4rxajlaR03os6a/2Q9+KElqIK0++itp5WIowQdhWurBeNZSHSYqJ1QvBO/fVAmq9M799XvVhCQdhQ/lbk71OH+MIb9ZFHSjucVGvnan76utRsg7kVSqCmcATN000c605dVimqzSmUppGFy6U6jeuPfTUnenEQ+mBQWbosnwoqaS9F5k+1NaCs3o2JYJ6JrPukt3mR4ctaAtKv9AuePJRMR+FqrUPxOVJ8nJQXrPVCt8lsH/2Uq8+Tgf8AXTU//ZH+JSpDjnzbvD/E4wr5ZvijnqM409cz/FHvuGsZs+jDuoxkdr1+gVsPWc5m26Su8p/mDaIjgPKMndPKPrIrGwm4jz+xhvOpW6efnISkbAZzkH6KZdHTYPvzCp4yL5fFK0nC0+8UU9PucsUkkDbxoYWe4zGlDsIFsSO7tUc5+w0SrPftVCKEx5NkjBPXlglZ+JUK1dU5xYA0fb7LLxtbxSXG3qojVThcOEhSie4DNUqRElLJ5Ysg+5pX5VddRai1dv22pCM9EsRktgfWapM263t7PaXyavx6V6N0mQXb639lwsjzkh1/T3UdIgzE5zDk/wB0r8qi5EWSP+Xe/sGnUpyUo5XPlLPtUPyqNfW9184fPd6w/Kqk7uYTCFp7CmzzEjO7Dv8AZNNlsPdSy4P6Br24XM47d341wU46P+Kv40rkITNgK8ltYO6Fj+ia7x/RWCQRv31wDzwOzy/jT6FOmNLBRKdT9NDZa6m+9kSNIujtGNxvitAWnexrT3ctZ/0vc7yVN8q7e/0wH4+frFGa13K8JtS0u2iG42pJ5lxJqmiBj5q0kUWtBLW6KrSEBxsVC+TjhOtNSAf9Onf+spU28n2e2zxDusZlh7spLCgFLUCUcqsgKwPYd6VIsd+bcRyCcYTpTAI76vSF6UvKSAQYT33DWNgedm5EbfriPqFbI1geXSd6PhBe+4axuhQTFuftfP4Ux6O7O7wqeNf18V8tRwsY8aJNnViMPaN6GlqV6Y8M0RbY5yw962MwuwLIjSQqE1M56Rz1zVOknc1atRuZVtVUkkDeujRq8zV6jJR2NRr29SMgg1HPdcUsqE4gTFzY1wX61d3PW3rgv1qVSJkxeKcRvWFN6cxR6Q99Qj3UpNkT9IjC2t+mKOVrI/Qrgzty0CNKuFLjP0Ubbc+BZFjPrJq1Wi7WqhSGznKs+TgsL13fD3mOr74pVx8m1WdfXv8Am6vvilWdxz5s9wT3Cvlwj3rI40jej/EXvuGsZJP+azxnP681s/VjSn9LXdpIypcN4Af0DWGhcnErkxwyolayelMOjxADr8wqmMAnLZStsVyqGTV9tz4VE3PdQ3hPrbwSMe+pljUDsdGO7FbPMHNsslIxwfcKQvzuV4GarUk5613m3rtzk1FPz0nYVCSRoFrqcML73suUg1HPHGa7PzAaYOyQaUzzNTiCIrm4qm6lb16W6Ca4qWM9KWPeCmDGr31pzH2UKZBfhTqMpRUAOtcjdqvSDREjTKwHGT4EZoyQZCRaSkHqKAtluL7BQUpbVg96sVchrW4RIZSqHzJAJylwGmskfEaLJOyThuN1aPJrI/y9vftjq++KVefJebde1ZeZKkFKUxznI7yoUqyeNa1Rt9FpsM0gC0kUpdbU2sZSoFJHiDWUeKWiHNNXt1pDRDO3ZqA2UnuNakYfI2O4qI1po+HrW1KjOKDchIPYvYzyk+PsoVDUmmkudip1UAnZYbhYqf5midzXAy+UYJNSer7KbNdJENyeh6QysoWltWcEHB+yq15rMcJ7Jp5Y8Qkmta2pcRpqs8YGg2KfqlpIpu48knamMhmYwkqcbcSO8lJApgq4YPrj40CWrI0cjRUt9WqTdCV95rgpgH5WaYi4Z+WPjX1M/wBL1h8arOnYd1aED27JyY3tr55rXkyVA75+FffO19Ak/CuXYvWevaIgJ36U9YYS3uBUemW4e5Xwp7GjTpQy008sfwUE1ONzb6BCkDrdYqUjOFvGDirBampFwdQ0OY8xwBVWEV5hSTM7WOCcemMZrQ/AnhtFnxv09LltS4aV8rSEKzzLGCc+HUUeWsEMZc5Vo6QyvsEQ+EmjxpmyqmOo5ZM1KAQRuEJzj4k/ZSq7rWEjAwAOgHdSrIyvdK8yO3K0sbBG0Mb2KPaX03rrLeLUCUtKikpZWoEdxCTvVXRcpQHePor5LuMp+G+yp0IDjS2+YjplJGfrqw6E3QGyiyx5qSwM3e4vPynni8sgLWnGTgYzuPjV24dtpsUdEKMhCm0nm5nEgqJPUmoG+NGzT3GJ7jbbqTjrlKvaD0NSenb/AGuM6O1mNJzjG9bekipheRtsxCydbJO4BhvYFXzWV5enaan2rzSFyzGFMlxTPpIJGygRuCDg/RWdJHD67tKUkNsrUPlJmMlJ9u6gfqo1Xq/QZMflYlNOE+CqpktxG5CknPtoNXhUFQ0F2luSlR4lPCS1uo+qHTmjryg4MZvbwfbP7VOLPpiS3cmXLihpuK0rtHAp0HtAN+QBJzk9Ppq0uqG/T6KaL91Kjg8DDcE+Y9k3GJzOFiB6+6TkpSySWmgSc7IG1cVEuDHIkZGNhivSgSc4NekhXzTVt1zuqosNlGRtMArAVLc5T1ynOPrrQPC+c5C081DYKQlgkJUUjP0+JoMslST0NETRuorfa4ZTLlIaVnOCck1GKmjY05QoTVMj3jMVDcabVc9TXqNcGXmQ+w32alK9HKQcjuOe+jD5KUCXa9H3RiTILqVSkuIA9VJIOce+hbqLUNqnOBTUtC+bIwAc5zRT4QuS7Xp98pUlCX3ApKQcnAB3PhnNVsRpIuEXt+I2/wDWVmgqpS8Md8IujQ4v20qqP6VmK+Uo0qRiApwZgpZptHzRXyYw0YzmUJ9Q/ZSpV0nVRGyDF8t0R95aXI7a0+BGRVZOj7BLKi9aoyiD15cfZSpVpYgCNUjkcQdFD3HRVgb5ii3JT/JcWPxqDk6YtKB6MZY9zy//AKpUqO6NltghMkffcqOdsUBJOGnB/XL/ADrj+iYgOyHOn78v86VKgFjeSNndbddU2eGU7tuf3q/zp9HsFuXy8zCj/Wr/ADpUqI1jeSE97ualYWlrOsjnhhXvcUfxqz2XRtgcWkrtjKt+8k/jSpVNzGgaBDa9xOpU47YLVBf5Y0BhoY+SmiLoCMyID2Gk+uO72UqVL64/sq9SfyK2hlv5gpUqVIrpvZf/2Q==);background-position:center;background-repeat:no-repeat;background-size:contain;border-radius:7px;filter:drop-shadow(0 2px 3px #001b44aa)}main{padding:16px!important}" +
                    ".card,.announcement{border-radius:20px!important;box-shadow:0 6px 22px #0d47a120!important;border:1.5px solid #90caf9!important}" +
                    ".card{padding:18px!important;margin-bottom:16px!important}" +
                    "button{border-radius:14px!important;min-height:48px;box-shadow:0 4px 10px #d6282825;transition:transform .15s ease,filter .15s ease}" +
                    "button:active{transform:scale(.98);filter:brightness(.96)}button.secondary{background:#172033!important}button.light{background:#edf1f7!important}" +
                    "input,select,textarea{border-radius:13px!important;background:#fff!important;border:1.5px solid #90caf9!important;min-height:46px;outline-color:#1976d2!important}" +
                    ".status{padding:7px 12px!important;letter-spacing:.1px;border:1px solid #64b5f6!important;border-radius:999px!important}.stat,.feature{border-radius:15px!important;background:#f4f8ff!important;border:1px solid #bbdefb!important}" +
                    "#map{border-radius:16px!important;box-shadow:0 3px 12px #17203312}.announcement{margin-bottom:16px!important}" +
                    ".announcement{display:none!important}.announcement-copy{padding:18px!important}footer{padding:22px 14px!important}" +
                    "@media(max-width:480px){main{padding:12px!important}.card{padding:15px!important}header h1{font-size:21px!important}}`;" +
                    "document.head.appendChild(s);const h=document.querySelector('header h1');if(h)h.textContent=h.textContent.replace(/^🏍️\s*/, '');})()";
                view.evaluateJavascript(script, null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                }
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= 21) runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        webView.loadUrl("https://birdaagas.netlify.app/");
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        String host = uri.getHost() == null ? "" : uri.getHost();
        if (scheme.equals("https") && (host.equals("birdaagas.netlify.app") || host.endsWith(".netlify.app") || host.equals("www.google.com") || host.equals("www.openstreetmap.org"))) return false;
        if (scheme.equals("http") || scheme.equals("https") || scheme.equals("waze") || scheme.equals("geo") || scheme.equals("tel") || scheme.equals("mailto")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
            return true;
        }
        return true;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST && pendingGeoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
