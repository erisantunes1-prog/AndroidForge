package br.com.motoboycontrol;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private Button button(String text, Runnable action) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0, dp(6), 0, dp(6)); b.setLayoutParams(p); return b;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(24), dp(22), dp(22)); root.setBackgroundColor(Color.rgb(246,248,252));
        TextView title = new TextView(this); title.setText("Trava Tela"); title.setTextSize(27); title.setTextColor(Color.rgb(16,24,40)); title.setGravity(Gravity.CENTER_VERTICAL); root.addView(title);
        TextView intro = new TextView(this); intro.setText("Configure dois pontos na tela. Depois, Volume + toca no ponto Aceitar e Volume − toca no ponto Mapa. Os marcadores desaparecem no modo ativo."); intro.setTextSize(16); intro.setTextColor(Color.rgb(71,84,103)); intro.setPadding(0,dp(12),0,dp(14)); root.addView(intro);
        root.addView(button("1 · Ativar serviço de acessibilidade", () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("2 · Abrir configuração dos marcadores", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_CONFIGURE); startService(i); finish(); }));
        root.addView(button("3 · Ativar modo invisível", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_ACTIVATE); startService(i); }));
        root.addView(button("Desativar modo invisível", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_DEACTIVATE); startService(i); }));
        TextView note = new TextView(this); note.setText("Importante: o Android pode limitar a captura de botões e os gestos do sistema. O botão físico Power não pode ser interceptado por um aplicativo comum; use o botão de desativação ou a combinação Volume + e Volume −. Teste parado, nunca pilotando."); note.setTextSize(13); note.setTextColor(Color.rgb(102,112,133)); note.setPadding(0,dp(18),0,0); root.addView(note);
        setContentView(root);
    }
}
