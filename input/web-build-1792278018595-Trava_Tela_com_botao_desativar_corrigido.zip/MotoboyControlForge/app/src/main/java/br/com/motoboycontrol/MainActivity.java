package br.com.motoboycontrol;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private Button button(String text, Runnable action) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0, dp(6), 0, dp(6)); b.setLayoutParams(p); return b;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(24), dp(22), dp(22)); root.setBackgroundColor(Color.rgb(246,248,252));
        ImageView appIcon = new ImageView(this);
        appIcon.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(104), dp(104));
        iconParams.gravity = Gravity.CENTER_HORIZONTAL;
        iconParams.setMargins(0, 0, 0, dp(10));
        appIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(appIcon, iconParams);
        TextView title = new TextView(this); title.setText("Trava Tela"); title.setTextSize(27); title.setTextColor(Color.rgb(16,24,40)); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView intro = new TextView(this); intro.setText("Use o botão flutuante com o ícone do aplicativo para ativar o bloqueio de qualquer tela. Arraste a bolha para posicioná-la. Você pode parar ou mostrar a bolha pelos botões abaixo. Configure os pontos de toque opcionais."); intro.setTextSize(16); intro.setTextColor(Color.rgb(71,84,103)); intro.setPadding(0,dp(12),0,dp(14)); root.addView(intro);
        root.addView(button("1 · Ativar serviço de acessibilidade", () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("2 · Abrir configuração dos marcadores", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_CONFIGURE); startService(i); finish(); }));
        root.addView(button("3 · Ativar modo invisível (ou use a bolha flutuante)", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_ACTIVATE); startService(i); }));
        root.addView(button("Desativar toques + e −", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_DEACTIVATE); startService(i); }));
        root.addView(button("Desativar modo invisível", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_DEACTIVATE); startService(i); }));
        root.addView(button("Parar bolha flutuante", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_STOP_BUBBLE); startService(i); }));
        root.addView(button("Mostrar bolha flutuante novamente", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_SHOW_BUBBLE); startService(i); }));
        Button rainOn = button("Proteção de chuva: ON", () -> {
            Intent i = new Intent(this, ControlAccessibilityService.class);
            i.setAction(ControlAccessibilityService.ACTION_RAIN_ON); startService(i);
        });
        Button rainOff = button("Proteção de chuva: OFF", () -> {
            Intent i = new Intent(this, ControlAccessibilityService.class);
            i.setAction(ControlAccessibilityService.ACTION_RAIN_OFF); startService(i);
        });
        root.addView(rainOn);
        root.addView(rainOff);
        TextView note = new TextView(this); note.setText("A bolha bloqueia os toques da tela do aplicativo que estiver aberto, mantendo a imagem visível. Para liberar, segure Volume + e Volume − juntos por cerca de 2 segundos. Este teste bloqueia toques na área coberta pela camada; a proteção contra chuva cobre apenas uma faixa superior e tenta fechar o painel se ele abrir; o Android pode ainda permitir o gesto de notificações. O botão Power é experimental. Teste parado, nunca pilotando."); note.setTextSize(13); note.setTextColor(Color.rgb(102,112,133)); note.setPadding(0,dp(18),0,0); root.addView(note);
        setContentView(root);
    }
}
