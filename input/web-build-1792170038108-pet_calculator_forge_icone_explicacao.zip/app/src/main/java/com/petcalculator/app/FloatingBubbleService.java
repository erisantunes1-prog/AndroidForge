package com.petcalculator.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

public class FloatingBubbleService extends Service {
    private static final String CHANNEL_ID = "pet_calculator_overlay";
    private WindowManager windowManager;
    private ImageView bubble;
    private WindowManager.LayoutParams params;
    private boolean added = false;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Pet Calculator ativo")
                    .setContentText("O botão flutuante está disponível sobre seus jogos")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentIntent(pending)
                    .setOngoing(true)
                    .build();
        } else {
            notification = new Notification.Builder(this)
                    .setContentTitle("Pet Calculator ativo")
                    .setContentText("O botão flutuante está disponível sobre seus jogos")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentIntent(pending)
                    .setOngoing(true)
                    .build();
        }
        startForeground(4201, notification);
        showBubble();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Botão flutuante", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mantém ativo o botão flutuante da Pet Calculator");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void showBubble() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return;
        if (added) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubble = new ImageView(this);
        bubble.setImageResource(R.mipmap.ic_launcher);
        bubble.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(2), Color.WHITE);
        bubble.setBackground(bg);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            bubble.setClipToOutline(true);
            bubble.setElevation(dp(6));
        }

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(dp(58), dp(58), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12);
        params.y = dp(180);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float downX, downY;
            private long downTime;
            private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x; startY = params.y;
                        downX = event.getRawX(); downY = event.getRawY();
                        downTime = System.currentTimeMillis(); moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - downX);
                        int dy = (int) (event.getRawY() - downY);
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        params.x = Math.max(0, startX - dx);
                        params.y = Math.max(0, startY + dy);
                        if (windowManager != null && added) windowManager.updateViewLayout(bubble, params);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && System.currentTimeMillis() - downTime < 500) {
                            Intent launch = new Intent(FloatingBubbleService.this, MainActivity.class);
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(launch);
                        }
                        return true;
                }
                return true;
            }
        });
        try {
            windowManager.addView(bubble, params);
            added = true;
        } catch (Exception ignored) { added = false; }
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!added) showBubble();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (windowManager != null && bubble != null && added) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) { }
        }
        added = false;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
