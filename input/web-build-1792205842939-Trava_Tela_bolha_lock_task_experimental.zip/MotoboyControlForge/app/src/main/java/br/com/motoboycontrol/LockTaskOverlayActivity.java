package br.com.motoboycontrol;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

/** Experimental transparent layer: requests Lock Task while the app underneath remains visible. */
public class LockTaskOverlayActivity extends Activity {
    private static volatile LockTaskOverlayActivity instance;
    private boolean requested = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        Window w = getWindow();
        w.setBackgroundDrawableResource(android.R.color.transparent);
        w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        View transparent = new View(this);
        transparent.setBackgroundColor(Color.TRANSPARENT);
        transparent.setOnTouchListener((v, event) -> true);
        setContentView(transparent);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!requested) {
            requested = true;
            try {
                startLockTask();
                Toast.makeText(this, "Solicitação Lock Task enviada. Confirme a fixação se o Android pedir.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "O Android não permitiu Lock Task: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            }
        }
    }

    static void exitIfRunning() {
        LockTaskOverlayActivity a = instance;
        if (a != null) a.runOnUiThread(() -> {
            try { a.stopLockTask(); } catch (Exception ignored) {}
            a.finish();
        });
    }

    @Override public void onBackPressed() {
        // Ignore Back while active; the service's volume-button combination is the intended exit.
    }

    @Override protected void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
