PUBLICAR A PAGINA DO CLIENTE NO FIREBASE HOSTING

1. Instale Node.js e Firebase CLI em um computador.
2. Abra um terminal nesta pasta firebase-hosting.
3. Execute: firebase login
4. Execute: firebase use birdagas-c697a (se pedir para associar o projeto).
5. Execute: firebase deploy --only hosting
6. O endereço padrão esperado será https://birdagas-c697a.web.app/ . Confirme no resultado do deploy.

IMPORTANTE SOBRE AS REGRAS DO REALTIME DATABASE
O código agora usa Firebase Realtime Database em /rides/{id}. O banco precisa ter regras adequadas antes de usar com clientes reais. Não habilite leitura/escrita pública irrestrita em produção: qualquer pessoa que obtenha o endereço do banco poderia acessar/alterar dados. Configure autenticação e regras por atendimento antes de colocar em uso real.

O link web só funcionará depois de publicar o Hosting e confirmar que o domínio mostrado pelo Firebase é o mesmo usado no código.
