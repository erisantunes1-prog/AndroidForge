# Adopt Me Flutuante (Android)

Projeto inicial Android Studio em Kotlin. Cria uma bolha arrastável que abre um painel WebView por cima de outros aplicativos, para uso manual com Roblox.

## Importante sobre o link
O link recebido foi `https://share.google/sIP91n7h0aoWvdcEg`. Ele parece ser um link de compartilhamento/redirect do Google, e não foi possível confirmar o endereço final da calculadora. Se não abrir corretamente, edite `CALCULATOR_URL` em `FloatingService.kt` e coloque a URL direta do site.

## Como compilar o APK
1. No computador, instale o Android Studio atual.
2. Extraia este ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `AdoptMeFlutuante`.
4. Aguarde a sincronização do Gradle e instale os componentes Android SDK solicitados.
5. Selecione **Build > Build APK(s)**.
6. O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfira o APK para o celular Android e instale. Talvez seja necessário autorizar a instalação dessa origem.

## Como usar
1. Abra o app.
2. Toque em **Permitir aparecer sobre outros apps** e habilite a permissão nas configurações do Android.
3. Volte ao app e toque em **Iniciar bolha flutuante**.
4. Abra o Roblox. Arraste a bolha roxa e toque nela para abrir o painel.
5. Faça login manualmente no site se ele solicitar. Não grave a senha no código.

## Limitações
- Este ZIP contém o projeto-fonte; não é um APK já compilado.
- A permissão de sobreposição precisa ser concedida pelo usuário.
- O comportamento de janela sobre o Roblox varia conforme o fabricante do Android e pode ser limitado pelo modo de tela cheia.
- Alguns sites bloqueiam WebView, exigem navegador externo ou não permitem login embutido. A compatibilidade precisa ser testada com a URL direta.
- A compilação Android requer Android Studio/SDK/Gradle em um computador. Não há APK final pré-compilado neste arquivo.
