package br.com.motoboycontrol;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Point;
import android.view.Display;

public class ControlAccessibilityService extends AccessibilityService {
    public static final String ACTION_CONFIGURE = "br.com.motoboycontrol.CONFIGURE";
    public static final String ACTION_ACTIVATE = "br.com.motoboycontrol.ACTIVATE";
    public static final String ACTION_DEACTIVATE = "br.com.motoboycontrol.DEACTIVATE";
    private WindowManager wm;
    private View plusMarker, minusMarker, blocker;
    private boolean active = false, plusDown = false, minusDown = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private int screenW, screenH;
    private float plusX=.5f, plusY=.75f, minusX=.5f, minusY=.85f;

    @Override public void onServiceConnected() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("points", MODE_PRIVATE);
        plusX=prefs.getFloat("plusX",.5f); plusY=prefs.getFloat("plusY",.72f); minusX=prefs.getFloat("minusX",.5f); minusY=prefs.getFloat("minusY",.84f);
        updateScreen();
        Toast.makeText(this,"Trava Tela ativado",Toast.LENGTH_SHORT).show();
    }
    private void updateScreen() { if (wm == null) return; Point p = new Point(); wm.getDefaultDisplay().getRealSize(p); screenW=p.x; screenH=p.y; }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction()!=null) {
            String a=intent.getAction();
            if (a.equals(ACTION_CONFIGURE)) showMarkers();
            else if (a.equals(ACTION_ACTIVATE)) activate();
            else if (a.equals(ACTION_DEACTIVATE)) deactivate();
        }
        return START_STICKY;
    }
    private WindowManager.LayoutParams params(int w,int h,int gravity,int type) {
        int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        return new WindowManager.LayoutParams(w,h,type,flags,PixelFormat.TRANSLUCENT);
    }
    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }
    private TextView marker(String label, int color) {
        TextView v=new TextView(this); v.setText(label); v.setTextColor(Color.WHITE); v.setTextSize(16); v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(color); bg.setShape(GradientDrawable.OVAL); bg.setStroke(3,Color.WHITE); v.setBackground(bg); v.setElevation(12); return v;
    }
    private void showMarkers() {
        deactivate(); removeMarkers(); updateScreen();
        plusMarker=marker("+",Color.rgb(28,160,90)); minusMarker=marker("−",Color.rgb(22,119,255));
        addMarker(plusMarker,plusX,plusY,true); addMarker(minusMarker,minusX,minusY,false);
        Toast.makeText(this,"Arraste + sobre Aceitar e − sobre Mapa. Saia pelo app Trava Tela para salvar.",Toast.LENGTH_LONG).show();
    }
    private void addMarker(View v,float x,float y,boolean plus) {
        WindowManager.LayoutParams lp=params(dp(64),dp(64),Gravity.TOP|Gravity.LEFT,overlayType());
        lp.x=(int)(x*screenW)-dp(32); lp.y=(int)(y*screenH)-dp(32);
        v.setOnTouchListener(new View.OnTouchListener(){ float sx,sy; int ox,oy; boolean moved;
            public boolean onTouch(View view, MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=lp.x;oy=lp.y;moved=false;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>5)moved=true;lp.x=ox+(int)dx;lp.y=oy+(int)dy;try{wm.updateViewLayout(view,lp);}catch(Exception ignored){}return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){float cx=(lp.x+dp(32))/(float)Math.max(1,screenW);float cy=(lp.y+dp(32))/(float)Math.max(1,screenH);cx=Math.max(.02f,Math.min(.98f,cx));cy=Math.max(.03f,Math.min(.97f,cy));if(plus){plusX=cx;plusY=cy;}else{minusX=cx;minusY=cy;}prefs.edit().putFloat("plusX",plusX).putFloat("plusY",plusY).putFloat("minusX",minusX).putFloat("minusY",minusY).apply();Toast.makeText(ControlAccessibilityService.this,(plus?"Ponto +":"Ponto −")+" salvo",Toast.LENGTH_SHORT).show();return true;}return true; }
        });
        try { wm.addView(v,lp); } catch(Exception ex){ Toast.makeText(this,"Não foi possível mostrar os marcadores. Ative o serviço de acessibilidade.",Toast.LENGTH_LONG).show(); }
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private void removeMarkers(){ if(wm!=null){try{if(plusMarker!=null)wm.removeView(plusMarker);}catch(Exception ignored){}try{if(minusMarker!=null)wm.removeView(minusMarker);}catch(Exception ignored){}} plusMarker=null;minusMarker=null; }
    private void activate(){ if(wm==null){Toast.makeText(this,"Ative primeiro o serviço de acessibilidade",Toast.LENGTH_LONG).show();return;} removeMarkers(); updateScreen(); active=true;
        blocker=new View(this); blocker.setBackgroundColor(Color.TRANSPARENT); blocker.setOnTouchListener((v,e)->true);
        WindowManager.LayoutParams lp=params(-1,-1,Gravity.TOP|Gravity.LEFT,overlayType()); lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        try{wm.addView(blocker,lp);Toast.makeText(this,"Modo ativo: + aceita, − aciona Mapa. Volume + e − juntos por 2 s desativam.",Toast.LENGTH_LONG).show();}catch(Exception e){active=false;Toast.makeText(this,"Falha ao ativar bloqueio",Toast.LENGTH_LONG).show();}
    }
    private void deactivate(){active=false; if(wm!=null&&blocker!=null){try{wm.removeView(blocker);}catch(Exception ignored){}}blocker=null; }
    private void clickAt(float nx,float ny){ updateScreen(); float x=nx*screenW,y=ny*screenH; Path path=new Path();path.moveTo(x,y);GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,80);GestureDescription.Builder b=new GestureDescription.Builder();b.addStroke(stroke);dispatchGesture(b.build(),null,null); }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP || event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_DOWN){
            boolean down=event.getAction()==KeyEvent.ACTION_DOWN;
            if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP)plusDown=down; else minusDown=down;
            if(plusDown&&minusDown){ handler.removeCallbacks(disableCombo);handler.postDelayed(disableCombo,1800); return true; }
            if(event.getAction()==KeyEvent.ACTION_UP){ if(active){ if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP)clickAt(plusX,plusY);else clickAt(minusX,minusY);return true;} }
            return active;
        }
        return false;
    }
    private final Runnable disableCombo=()->{if(plusDown&&minusDown){deactivate();Toast.makeText(this,"Modo de bloqueio desativado",Toast.LENGTH_SHORT).show();}};
    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) { }
    @Override public void onInterrupt() { deactivate(); }
    @Override public void onDestroy(){deactivate();removeMarkers();super.onDestroy();}
}
