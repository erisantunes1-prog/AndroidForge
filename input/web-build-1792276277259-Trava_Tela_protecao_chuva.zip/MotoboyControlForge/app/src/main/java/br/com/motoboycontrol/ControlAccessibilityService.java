package br.com.motoboycontrol;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.Point;
import android.view.Display;

public class ControlAccessibilityService extends AccessibilityService {
    public static final String ACTION_CONFIGURE = "br.com.motoboycontrol.CONFIGURE";
    public static final String ACTION_ACTIVATE = "br.com.motoboycontrol.ACTIVATE";
    public static final String ACTION_DEACTIVATE = "br.com.motoboycontrol.DEACTIVATE";
    public static final String ACTION_STOP_BUBBLE = "br.com.motoboycontrol.STOP_BUBBLE";
    public static final String ACTION_SHOW_BUBBLE = "br.com.motoboycontrol.SHOW_BUBBLE";
    public static final String ACTION_RAIN_ON = "br.com.motoboycontrol.RAIN_ON";
    public static final String ACTION_RAIN_OFF = "br.com.motoboycontrol.RAIN_OFF";
    private WindowManager wm;
    private View plusMarker, minusMarker, blocker, topGuard, floatingButton, rainGuard;
    private boolean rainProtection = false;
    private boolean active = false, plusDown = false, minusDown = false, comboTriggered = false;
    private boolean bubbleSuppressed = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int powerClicks = 0;
    private final Runnable powerClickAction = new Runnable() {
        @Override public void run() {
            int clicks = powerClicks;
            powerClicks = 0;
            if (clicks >= 2) {
                if (!active) activate();
            } else if (clicks == 1 && active) {
                deactivate();
                Toast.makeText(ControlAccessibilityService.this, "Modo de bloqueio desativado", Toast.LENGTH_SHORT).show();
            }
        }
    };
    private SharedPreferences prefs;
    private boolean screenReceiverRegistered = false;
    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                // Ao apagar a tela pelo botão Power, remova apenas a camada de bloqueio.
                // O serviço de acessibilidade continua ativo e a bolha volta a aparecer.
                if (active) {
                    deactivate();
                    handler.removeCallbacks(powerClickAction);
                    powerClicks = 0;
                }
            }
        }
    };
    private int screenW, screenH;
    private float plusX=.5f, plusY=.75f, minusX=.5f, minusY=.85f;

    @Override public void onServiceConnected() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("points", MODE_PRIVATE);
        plusX=prefs.getFloat("plusX",.5f); plusY=prefs.getFloat("plusY",.72f); minusX=prefs.getFloat("minusX",.5f); minusY=prefs.getFloat("minusY",.84f);
        updateScreen();
        showFloatingButton();
        if (!screenReceiverRegistered) {
            IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
            registerReceiver(screenReceiver, filter);
            screenReceiverRegistered = true;
        }
        Toast.makeText(this,"Trava Tela ativado",Toast.LENGTH_SHORT).show();
    }
    private void updateScreen() { if (wm == null) return; Point p = new Point(); wm.getDefaultDisplay().getRealSize(p); screenW=p.x; screenH=p.y; }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction()!=null) {
            String a=intent.getAction();
            if (a.equals(ACTION_CONFIGURE)) showMarkers();
            else if (a.equals(ACTION_ACTIVATE)) activate();
            else if (a.equals(ACTION_DEACTIVATE)) deactivate();
            else if (a.equals(ACTION_STOP_BUBBLE)) {
                removeFloatingButton();
                Toast.makeText(this, "Bolha flutuante parada. Para voltar, abra o Trava Tela e toque em Mostrar bolha flutuante novamente.", Toast.LENGTH_LONG).show();
            }
            else if (a.equals(ACTION_SHOW_BUBBLE)) {
                showFloatingButton();
                Toast.makeText(this, floatingButton != null ? "Bolha flutuante exibida" : "Não foi possível mostrar a bolha. Desative o bloqueio e confira se a acessibilidade está ativa.", Toast.LENGTH_SHORT).show();
            }
        }
        return START_STICKY;
    }
    private WindowManager.LayoutParams params(int w,int h,int gravity,int type) {
        int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        return new WindowManager.LayoutParams(w,h,type,flags,PixelFormat.TRANSLUCENT);
    }
    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }
    private TextView marker(String label, int color) {
        TextView v=new TextView(this); v.setText(label); v.setTextColor(Color.WHITE); v.setTextSize(16); v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(color); bg.setShape(GradientDrawable.OVAL); bg.setStroke(3,Color.WHITE); v.setBackground(bg); v.setElevation(12); return v;
    }
    private void enableRainProtection() {
        if (wm == null) { Toast.makeText(this, "Ative primeiro o serviço de acessibilidade", Toast.LENGTH_LONG).show(); return; }
        if (rainGuard != null) { Toast.makeText(this, "Proteção do topo já está ativa", Toast.LENGTH_SHORT).show(); return; }
        rainProtection = true;
        rainGuard = new View(this);
        rainGuard.setBackgroundColor(Color.TRANSPARENT);
        rainGuard.setClickable(true);
        rainGuard.setOnTouchListener((v, e) -> true);
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, dp(72), overlayType(), flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        try {
            wm.addView(rainGuard, lp);
            Toast.makeText(this, "Proteção do topo ativada. É uma tentativa: o Android pode permitir o gesto de notificações.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            rainGuard = null; rainProtection = false;
            Toast.makeText(this, "Não foi possível ativar a proteção do topo", Toast.LENGTH_LONG).show();
        }
    }
    private void disableRainProtection() {
        rainProtection = false;
        if (wm != null && rainGuard != null) { try { wm.removeView(rainGuard); } catch (Exception ignored) {} }
        rainGuard = null;
        Toast.makeText(this, "Proteção do topo desativada", Toast.LENGTH_SHORT).show();
    }
    private void showFloatingButton() {
        if (wm == null || active || floatingButton != null || bubbleSuppressed) return;
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(22,119,255));
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(2), Color.WHITE);
        icon.setBackground(bg);
        icon.setClipToOutline(true);
        icon.setElevation(dp(10));
        floatingButton = icon;
        WindowManager.LayoutParams lp = params(dp(60), dp(60), Gravity.TOP | Gravity.LEFT, overlayType());
        lp.x = dp(14);
        lp.y = dp(220);
        icon.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (Math.abs(dx) + Math.abs(dy) > dp(7)) moved = true;
                    lp.x = ox + (int) dx; lp.y = oy + (int) dy;
                    try { wm.updateViewLayout(v, lp); } catch (Exception ignored) {}
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) activate();
                    return true;
                }
                return true;
            }
        });
        try { wm.addView(icon, lp); }
        catch (Exception e) { floatingButton = null; Toast.makeText(this, "Não foi possível exibir o botão flutuante. Confira se o serviço de acessibilidade está ativo.", Toast.LENGTH_LONG).show(); }
    }
    private void removeFloatingButton() {
        if (wm != null && floatingButton != null) { try { wm.removeView(floatingButton); } catch (Exception ignored) {} }
        floatingButton = null;
    }
    private void showMarkers() {
        deactivate(); removeFloatingButton(); removeMarkers(); updateScreen();
        plusMarker=marker("+",Color.rgb(28,160,90)); minusMarker=marker("−",Color.rgb(22,119,255));
        addMarker(plusMarker,plusX,plusY,true); addMarker(minusMarker,minusX,minusY,false);
        Toast.makeText(this,"Arraste + sobre Aceitar e − sobre Mapa. Saia pelo app Trava Tela para salvar.",Toast.LENGTH_LONG).show();
    }
    private void addMarker(View v,float x,float y,boolean plus) {
        WindowManager.LayoutParams lp=params(dp(64),dp(64),Gravity.TOP|Gravity.LEFT,overlayType());
        lp.x=(int)(x*screenW)-dp(32); lp.y=(int)(y*screenH)-dp(32);
        v.setOnTouchListener(new View.OnTouchListener(){ float sx,sy; int ox,oy; boolean moved;
            public boolean onTouch(View view, MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=lp.x;oy=lp.y;moved=false;return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)+Math.abs(dy)>5)moved=true;lp.x=ox+(int)dx;lp.y=oy+(int)dy;try{wm.updateViewLayout(view,lp);}catch(Exception ignored){}return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){float cx=(lp.x+dp(32))/(float)Math.max(1,screenW);float cy=(lp.y+dp(32))/(float)Math.max(1,screenH);cx=Math.max(.02f,Math.min(.98f,cx));cy=Math.max(.03f,Math.min(.97f,cy));if(plus){plusX=cx;plusY=cy;}else{minusX=cx;minusY=cy;}prefs.edit().putFloat("plusX",plusX).putFloat("plusY",plusY).putFloat("minusX",minusX).putFloat("minusY",minusY).apply();Toast.makeText(ControlAccessibilityService.this,(plus?"Ponto +":"Ponto −")+" salvo",Toast.LENGTH_SHORT).show();return true;}return true; }
        });
        try { wm.addView(v,lp); } catch(Exception ex){ Toast.makeText(this,"Não foi possível mostrar os marcadores. Ative o serviço de acessibilidade.",Toast.LENGTH_LONG).show(); }
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private void removeMarkers(){ if(wm!=null){try{if(plusMarker!=null)wm.removeView(plusMarker);}catch(Exception ignored){}try{if(minusMarker!=null)wm.removeView(minusMarker);}catch(Exception ignored){}} plusMarker=null;minusMarker=null; }
    private void activate(){ if(wm==null){Toast.makeText(this,"Ative primeiro o serviço de acessibilidade",Toast.LENGTH_LONG).show();return;} removeFloatingButton(); removeMarkers(); updateScreen(); active=true;
        blocker=new View(this);
        blocker.setBackgroundColor(Color.TRANSPARENT);
        blocker.setClickable(true);
        blocker.setFocusable(false);
        // Camada transparente em tela cheia: tenta cobrir também as áreas das barras do sistema
        // e consumir qualquer toque/gesto sem trocar o aplicativo que está por baixo.
        blocker.setOnTouchListener((v,e)->true);
        blocker.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        WindowManager.LayoutParams lp=params(-1,-1,Gravity.TOP|Gravity.LEFT,overlayType());
        lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
        try {
            wm.addView(blocker,lp);
            // Segunda camada transparente de tela INTEIRA, posicionada acima do bloqueador.
            // Ela consome os toques comuns em toda a área disponível, inclusive a região superior.
            // O Android pode priorizar gestos reservados do sistema; não há garantia de interceptá-los.
            topGuard = new View(this);
            topGuard.setBackgroundColor(Color.TRANSPARENT);
            topGuard.setClickable(true);
            topGuard.setFocusable(false);
            topGuard.setOnTouchListener((v,e)->true);
            int guardFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN;
            WindowManager.LayoutParams guardLp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    overlayType(), guardFlags, PixelFormat.TRANSLUCENT);
            guardLp.gravity = Gravity.TOP | Gravity.LEFT;
            if (Build.VERSION.SDK_INT >= 28) guardLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            wm.addView(topGuard,guardLp);
            Toast.makeText(this,"Bloqueio de tela ativado. Para liberar, segure Volume + e Volume − juntos por 2 s.",Toast.LENGTH_LONG).show();
        } catch(Exception e) {
            if(topGuard!=null){try{wm.removeView(topGuard);}catch(Exception ignored){} topGuard=null;}
            if(blocker!=null){try{wm.removeView(blocker);}catch(Exception ignored){} blocker=null;}
            active=false;
            Toast.makeText(this,"Falha ao ativar bloqueio",Toast.LENGTH_LONG).show();
        }
    }
    private void deactivate(){
        active=false;
        if(wm!=null&&topGuard!=null){try{wm.removeView(topGuard);}catch(Exception ignored){}}
        topGuard=null;
        if(wm!=null&&blocker!=null){try{wm.removeView(blocker);}catch(Exception ignored){}}
        blocker=null;
        if (wm != null) showFloatingButton();
    }
    private void clickAt(float nx,float ny){ updateScreen(); float x=nx*screenW,y=ny*screenH; Path path=new Path();path.moveTo(x,y);GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,80);GestureDescription.Builder b=new GestureDescription.Builder();b.addStroke(stroke);dispatchGesture(b.build(),null,null); }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        // Tentativa opcional: o Android normalmente reserva POWER para o sistema e pode
        // nunca encaminhar esse evento ao serviço de acessibilidade.
        if (event.getKeyCode() == KeyEvent.KEYCODE_POWER) {
            if (event.getAction() == KeyEvent.ACTION_UP && event.getRepeatCount() == 0) {
                powerClicks++;
                handler.removeCallbacks(powerClickAction);
                handler.postDelayed(powerClickAction, 450);
                return true;
            }
            return true;
        }
        if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP || event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_DOWN){
            boolean down=event.getAction()==KeyEvent.ACTION_DOWN;
            if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP)plusDown=down; else minusDown=down;
            if(plusDown && minusDown){
                if(!handler.hasCallbacks(disableCombo)) handler.postDelayed(disableCombo,1800);
                return true;
            }
            if(event.getAction()==KeyEvent.ACTION_UP){
                handler.removeCallbacks(disableCombo);
                if(comboTriggered){
                    if(!plusDown && !minusDown) comboTriggered=false;
                    return true;
                }
                if(active){
                    if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP) clickAt(plusX,plusY); else clickAt(minusX,minusY);
                    return true;
                }
            }
            return active;
        }
        return false;
    }
    private final Runnable disableCombo=()->{if(plusDown&&minusDown){comboTriggered=true;deactivate();Toast.makeText(this,"Modo de bloqueio desativado",Toast.LENGTH_SHORT).show();}};
    private long lastShadeDismissAt = 0;
    private void dismissShadeAttempt(int attempt) {
        if ((!active && !rainProtection) || attempt >= 3) return;
        try { performGlobalAction(GLOBAL_ACTION_BACK); } catch (Exception ignored) {}
        if (attempt < 2) handler.postDelayed(() -> dismissShadeAttempt(attempt + 1), 180);
    }
    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {
        if ((!active && !rainProtection) || event == null) return;
        CharSequence pkg = event.getPackageName();
        CharSequence cls = event.getClassName();
        String packageName = pkg == null ? "" : pkg.toString();
        String className = cls == null ? "" : cls.toString();
        String eventText = event.getText() == null ? "" : event.getText().toString();
        String combined = (packageName + " " + className + " " + eventText).toLowerCase(java.util.Locale.ROOT);
        boolean systemUi = packageName.equals("com.android.systemui");
        boolean shade = combined.contains("notification shade")
                || combined.contains("notificationshade")
                || combined.contains("statusbarwindow")
                || combined.contains("statusbar")
                || combined.contains("quicksettings")
                || combined.contains("quick settings")
                || combined.contains("notificationpanel")
                || combined.contains("notification_panel")
                || combined.contains("notification shade window")
                || combined.contains("notificationpanelview")
                || combined.contains("quicksettingscontainer");
        long now = android.os.SystemClock.uptimeMillis();
        if (systemUi && shade && now - lastShadeDismissAt > 700) {
            lastShadeDismissAt = now;
            handler.postDelayed(() -> dismissShadeAttempt(0), 60);
        }
    }
    @Override public void onInterrupt() { deactivate(); }
    @Override public void onDestroy(){
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
            screenReceiverRegistered = false;
        }
        handler.removeCallbacks(powerClickAction);
        handler.removeCallbacks(disableCombo);
        removeFloatingButton();deactivate();disableRainProtection();removeMarkers();super.onDestroy();
    }
}
