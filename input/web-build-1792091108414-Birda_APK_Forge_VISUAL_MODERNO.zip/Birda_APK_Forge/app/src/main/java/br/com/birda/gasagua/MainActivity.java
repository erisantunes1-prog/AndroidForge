package br.com.birda.gasagua;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 7001;
    private WebView webView;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Visual-only polish inside this app; live Netlify and Firebase remain untouched.
                String script = "(()=>{if(document.getElementById('birda-app-polish'))return;" +
                    "const s=document.createElement('style');s.id='birda-app-polish';" +
                    "s.textContent=`html{scroll-behavior:smooth}body{font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif!important;background:#f2f5fa!important;color:#172033!important}" +
                    "header{background:linear-gradient(135deg,#c9152a,#ed3346)!important;padding:22px 18px!important;box-shadow:0 5px 18px #17203320!important}" +
                    "header h1{font-size:23px!important;letter-spacing:-.4px}main{padding:16px!important}" +
                    ".card,.announcement{border-radius:20px!important;box-shadow:0 6px 22px #14213d12!important;border:1px solid #e9edf4!important}" +
                    ".card{padding:18px!important;margin-bottom:16px!important}" +
                    "button{border-radius:14px!important;min-height:48px;box-shadow:0 4px 10px #d6282825;transition:transform .15s ease,filter .15s ease}" +
                    "button:active{transform:scale(.98);filter:brightness(.96)}button.secondary{background:#172033!important}button.light{background:#edf1f7!important}" +
                    "input{border-radius:13px!important;background:#fff!important;border-color:#dce3ed!important;min-height:46px}" +
                    ".status{padding:7px 12px!important;letter-spacing:.1px}.stat,.feature{border-radius:15px!important;background:#f4f7fb!important}" +
                    "#map{border-radius:16px!important;box-shadow:0 3px 12px #17203312}.announcement{margin-bottom:16px!important}" +
                    ".announcement-copy{padding:18px!important}footer{padding:22px 14px!important}" +
                    "@media(max-width:480px){main{padding:12px!important}.card{padding:15px!important}header h1{font-size:21px!important}}`;" +
                    "document.head.appendChild(s)})()";
                view.evaluateJavascript(script, null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin;
                    pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                }
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= 21) runOnUiThread(() -> request.grant(request.getResources()));
            }
        });
        webView.loadUrl("https://birdaagas.netlify.app/");
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        String host = uri.getHost() == null ? "" : uri.getHost();
        if (scheme.equals("https") && (host.equals("birdaagas.netlify.app") || host.endsWith(".netlify.app") || host.equals("www.google.com") || host.equals("www.openstreetmap.org"))) return false;
        if (scheme.equals("http") || scheme.equals("https") || scheme.equals("waze") || scheme.equals("geo") || scheme.equals("tel") || scheme.equals("mailto")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
            return true;
        }
        return true;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST && pendingGeoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
