package br.com.motoboycontrol;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import android.graphics.Point;
import android.view.Display;

public class ControlAccessibilityService extends AccessibilityService {
    public static final String ACTION_CONFIGURE = "br.com.motoboycontrol.CONFIGURE";
    public static final String ACTION_ACTIVATE = "br.com.motoboycontrol.ACTIVATE";
    public static final String ACTION_DEACTIVATE = "br.com.motoboycontrol.DEACTIVATE";
    public static final String ACTION_STOP_BUBBLE = "br.com.motoboycontrol.STOP_BUBBLE";
    public static final String ACTION_SHOW_BUBBLE = "br.com.motoboycontrol.SHOW_BUBBLE";
    public static final String ACTION_RAIN_ON = "br.com.motoboycontrol.RAIN_ON";
    public static final String ACTION_RAIN_OFF = "br.com.motoboycontrol.RAIN_OFF";
    private WindowManager wm;
    private View plusMarker, minusMarker, blocker, topGuard, floatingButton, rainGuard;
    private boolean rainProtection = false;
    private boolean active = false, plusDown = false, minusDown = false, comboTriggered = false;
    private boolean bubbleSuppressed = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int powerClicks = 0;
    private final Runnable powerClickAction = new Runnable() {
        @Override public void run() {
            int clicks = powerClicks;
            powerClicks = 0;
            if (clicks >= 2) {
                if (!active) activate();
            } else if (clicks == 1 && active) {
                deactivate();
                Toast.makeText(ControlAccessibilityService.this, "Modo de bloqueio desativado", Toast.LENGTH_SHORT).show();
            }
        }
    };
    private SharedPreferences prefs;
    private boolean screenReceiverRegistered = false;
    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                // Ao apagar a tela pelo botão Power, remova apenas a camada de bloqueio.
                // O serviço de acessibilidade continua ativo e a bolha volta a aparecer.
                if (active) {
                    deactivate();
                    handler.removeCallbacks(powerClickAction);
                    powerClicks = 0;
                }
            }
        }
    };
    private int screenW, screenH;
    private float plusX=.5f, plusY=.75f, minusX=.5f, minusY=.85f;

    @Override public void onServiceConnected() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("points", MODE_PRIVATE);
        plusX=prefs.getFloat("plusX",.5f); plusY=prefs.getFloat("plusY",.72f); minusX=prefs.getFloat("minusX",.5f); minusY=prefs.getFloat("minusY",.84f);
        updateScreen();
        showFloatingButton();
        if (!screenReceiverRegistered) {
            IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
            registerReceiver(screenReceiver, filter);
            screenReceiverRegistered = true;
        }
        Toast.makeText(this,"Trava Tela ativado",Toast.LENGTH_SHORT).show();
    }
    private void updateScreen() { if (wm == null) return; Point p = new Point(); wm.getDefaultDisplay().getRealSize(p); screenW=p.x; screenH=p.y; }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction()!=null) {
            String a=intent.getAction();
            if (a.equals(ACTION_CONFIGURE)) showMarkers();
            else if (a.equals(ACTION_ACTIVATE)) activate();
            else if (a.equals(ACTION_DEACTIVATE)) deactivate();
            else if (a.equals(ACTION_RAIN_ON)) enableRainProtection();
            else if (a.equals(ACTION_RAIN_OFF)) disableRainProtection();
            else if (a.equals(ACTION_STOP_BUBBLE)) {
                removeFloatingButton();
                Toast.makeText(this, "Bolha flutuante parada. Para voltar, abra o Trava Tela e toque em Mostrar bolha flutuante novamente.", Toast.LENGTH_LONG).show();
            }
            else if (a.equals(ACTION_SHOW_BUBBLE)) {
                showFloatingButton();
                Toast.makeText(this, floatingButton != null ? "Bolha flutuante exibida" : "Não foi possível mostrar a bolha. Desative o bloqueio e confira se a acessibilidade está ativa.", Toast.LENGTH_SHORT).show();
            }
        }
        return START_STICKY;
    }
    private WindowManager.LayoutParams params(int w,int h,int gravity,int type) {
        int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        return new WindowManager.LayoutParams(w,h,type,flags,PixelFormat.TRANSLUCENT);
    }
    private int overlayType() { return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE; }
    private TextView marker(String label, int color) {
        TextView v=new TextView(this); v.setText(label); v.setTextColor(Color.WHITE); v.setTextSize(16); v.setTypeface(Typeface.DEFAULT_BOLD); v.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(color); bg.setShape(GradientDrawable.OVAL); bg.setStroke(3,Color.WHITE); v.setBackground(bg); v.setElevation(12); return v;
    }
    private void enableRainProtection() {
        if (wm == null) { Toast.makeText(this, "Ative primeiro o serviço de acessibilidade", Toast.LENGTH_LONG).show(); return; }
        if (rainGuard != null) { Toast.makeText(this, "Proteção de chuva: ON", Toast.LENGTH_SHORT).show(); return; }
        rainProtection = true;
        rainGuard = new View(this);
        rainGuard.setBackgroundColor(Color.TRANSPARENT);
        rainGuard.setClickable(true);
        rainGuard.setOnTouchListener((v, e) -> true);
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, dp(72), overlayType(), flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        try {
            wm.addView(rainGuard, lp);
            Toast.makeText(this, "Proteção de chuva: ON. O Android ainda pode permitir o gesto de notificações.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            rainGuard = null; rainProtection = false;
            Toast.makeText(this, "Não foi possível ativar a proteção do topo", Toast.LENGTH_LONG).show();
        }
    }
    private void disableRainProtection() {
        rainProtection = false;
        if (wm != null && rainGuard != null) { try { wm.removeView(rainGuard); } catch (Exception ignored) {} }
        rainGuard = null;
        Toast.makeText(this, "Proteção de chuva: OFF", Toast.LENGTH_SHORT).show();
    }
    private void showFloatingButton() {
        if (wm == null || active || floatingButton != null || bubbleSuppressed) return;
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(22,119,255));
        bg.setShape(GradientDrawable.OVAL);
        bg.setStroke(dp(2), Color.WHITE);
        icon.setBackground(bg);
        icon.setClipToOutline(true);
        icon.setElevation(dp(10));
        floatingButton = icon;
        WindowManager.LayoutParams lp = params(dp(60), dp(60), Gravity.TOP | Gravity.LEFT, overlayType());
        lp.x = dp(14);
        lp.y = dp(220);
        icon.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = e.getRawX(); sy = e.getRawY(); ox = lp.x; oy = lp.y; moved = false; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - sx, dy = e.getRawY() - sy;
                    if (Math.abs(dx) + Math.abs(dy) > dp(7)) moved = true;
                    lp.x = ox + (int) dx; lp.y = oy + (int) dy;
                    try { wm.updateViewLayout(v, lp); } catch (Exception ignored) {}
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) activate();
                    return true;
                }
                return true;
            }
        });
        try { wm.addView(icon, lp); }
        catch (Exception e) { floatingButton = null; Toast.makeText(this, "Não foi possível exibir o botão flutuante. Confira se o serviço de acessibilidade está ativo.", Toast.LENGTH_LONG).show(); }
    }
    private void removeFloatingButton() {
        if (wm != null && floatingButton != null) { try { wm.removeView(floatingButton); } catch (Exception ignored) {} }
        floatingButton = null;
    }
    private void showMarkers() {
        deactivate(); removeFloatingButton(); removeMarkers(); updateScreen();
        clickTargetsMode = false;
        plusMarker=marker("+",Color.rgb(28,160,90)); minusMarker=marker("−",Color.rgb(22,119,255));
        addMarker(plusMarker,plusX,plusY,true); addMarker(minusMarker,minusX,minusY,false);
        Toast.makeText(this,"Arraste + e − para posicionar. Toque na bolha do Trava Tela para ativar os toques.",Toast.LENGTH_LONG).show();
    }
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private void removeMarkers(){ if(wm!=null){try{if(plusMarker!=null)wm.removeView(plusMarker);}catch(Exception ignored){}try{if(minusMarker!=null)wm.removeView(minusMarker);}catch(Exception ignored){}} plusMarker=null;minusMarker=null; }
    private void activate(){
        if(wm==null){Toast.makeText(this,"Ative primeiro o serviço de acessibilidade",Toast.LENGTH_LONG).show();return;}
        removeFloatingButton(); removeMarkers();
        if(wm!=null&&blocker!=null){try{wm.removeView(blocker);}catch(Exception ignored){}}
        blocker=null;
        if(wm!=null&&topGuard!=null){try{wm.removeView(topGuard);}catch(Exception ignored){}}
        topGuard=null;
        updateScreen(); active=true; clickTargetsMode=true; markerClickInProgress=false;
        plusMarker=marker("+",Color.rgb(28,160,90)); minusMarker=marker("−",Color.rgb(22,119,255));
        addMarker(plusMarker,plusX,plusY,true); addMarker(minusMarker,minusX,minusY,false);
        Toast.makeText(this,"Toques prontos: toque em + ou − para tocar na posição marcada. A tela fora dos marcadores continua funcionando.",Toast.LENGTH_LONG).show();
    }
    private void deactivate(){
        active=false; clickTargetsMode=false; markerClickInProgress=false;
        if(wm!=null&&topGuard!=null){try{wm.removeView(topGuard);}catch(Exception ignored){}}
        topGuard=null;
        if(wm!=null&&blocker!=null){try{wm.removeView(blocker);}catch(Exception ignored){}}
        blocker=null;
        removeMarkers();
        if (wm != null) showFloatingButton();
    }
    private void clickAt(float nx,float ny){ updateScreen(); float x=nx*screenW,y=ny*screenH; Path path=new Path();path.moveTo(x,y);GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(path,0,80);GestureDescription.Builder b=new GestureDescription.Builder();b.addStroke(stroke);dispatchGesture(b.build(),null,null); }
    @Override protected boolean onKeyEvent(KeyEvent event) {
        // Tentativa opcional: o Android normalmente reserva POWER para o sistema e pode
        // nunca encaminhar esse evento ao serviço de acessibilidade.
        if (event.getKeyCode() == KeyEvent.KEYCODE_POWER) {
            if (event.getAction() == KeyEvent.ACTION_UP && event.getRepeatCount() == 0) {
                powerClicks++;
                handler.removeCallbacks(powerClickAction);
                handler.postDelayed(powerClickAction, 450);
                return true;
            }
            return true;
        }
        if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP || event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_DOWN){
            boolean down=event.getAction()==KeyEvent.ACTION_DOWN;
            if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP)plusDown=down; else minusDown=down;
            if(plusDown && minusDown){
                if(!handler.hasCallbacks(disableCombo)) handler.postDelayed(disableCombo,1800);
                return true;
            }
            if(event.getAction()==KeyEvent.ACTION_UP){
                handler.removeCallbacks(disableCombo);
                if(comboTriggered){
                    if(!plusDown && !minusDown) comboTriggered=false;
                    return true;
                }
                if(active){
                    if(event.getKeyCode()==KeyEvent.KEYCODE_VOLUME_UP) clickAt(plusX,plusY); else clickAt(minusX,minusY);
                    return true;
                }
            }
            return active;
        }
        return false;
    }
    private final Runnable disableCombo=()->{if(plusDown&&minusDown){comboTriggered=true;deactivate();Toast.makeText(this,"Modo de bloqueio desativado",Toast.LENGTH_SHORT).show();}};
    private long lastShadeDismissAt = 0;
    private void dismissShadeAttempt(int attempt) {
        if ((!active && !rainProtection) || attempt >= 3) return;
        try { performGlobalAction(GLOBAL_ACTION_BACK); } catch (Exception ignored) {}
        if (attempt < 2) handler.postDelayed(() -> dismissShadeAttempt(attempt + 1), 180);
    }
    @Override public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {
        if ((!active && !rainProtection) || event == null) return;
        CharSequence pkg = event.getPackageName();
        CharSequence cls = event.getClassName();
        String packageName = pkg == null ? "" : pkg.toString();
        String className = cls == null ? "" : cls.toString();
        String eventText = event.getText() == null ? "" : event.getText().toString();
        String combined = (packageName + " " + className + " " + eventText).toLowerCase(java.util.Locale.ROOT);
        boolean systemUi = packageName.equals("com.android.systemui");
        boolean shade = combined.contains("notification shade")
                || combined.contains("notificationshade")
                || combined.contains("statusbarwindow")
                || combined.contains("statusbar")
                || combined.contains("quicksettings")
                || combined.contains("quick settings")
                || combined.contains("notificationpanel")
                || combined.contains("notification_panel")
                || combined.contains("notification shade window")
                || combined.contains("notificationpanelview")
                || combined.contains("quicksettingscontainer");
        long now = android.os.SystemClock.uptimeMillis();
        if (systemUi && shade && now - lastShadeDismissAt > 700) {
            lastShadeDismissAt = now;
            handler.postDelayed(() -> dismissShadeAttempt(0), 60);
        }
    }
    @Override public void onInterrupt() { deactivate(); }
    @Override public void onDestroy(){
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
            screenReceiverRegistered = false;
        }
        handler.removeCallbacks(powerClickAction);
        handler.removeCallbacks(disableCombo);
        removeFloatingButton();deactivate();disableRainProtection();removeMarkers();super.onDestroy();
    }
}
