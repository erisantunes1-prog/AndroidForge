package com.example.adoptmeflutuante

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    companion object {
        // Link fornecido pelo usuário. Se for apenas um link de compartilhamento do Google,
        // substitua pela URL direta da calculadora quando souber o endereço final.
        private const val CALCULATOR_URL = "https://elvebredd.com/adopt-me-calculator"
        private const val CHANNEL_ID = "adoptme_floating_channel"
        private const val NOTIFICATION_ID = 7114
    }

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var webView: WebView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val label = TextView(this).apply {
            text = "🐾"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(102, 65, 170))
            elevation = 12f
            contentDescription = "Abrir calculadora Adopt Me"
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(58), dp(58), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(180)
        }

        label.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0
            private var downY = 0
            private var startX = 0
            private var startY = 0
            private var moved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = bubbleParams ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX.toInt()
                        downY = event.rawY.toInt()
                        startX = p.x
                        startY = p.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX.toInt() - downX
                        val dy = event.rawY.toInt() - downY
                        if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(8)) moved = true
                        p.x = startX + dx
                        p.y = startY + dy
                        try { wm.updateViewLayout(label, p) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) showPanel()
                        return true
                    }
                }
                return false
            }
        })

        bubble = label
        try { wm.addView(label, bubbleParams) } catch (e: Exception) {
            bubble = null
            Toast.makeText(this, "Não foi possível criar a bolha. Confira a permissão de sobreposição.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun showPanel() {
        if (panel != null) {
            panel?.visibility = View.VISIBLE
            return
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18f
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(102, 65, 170))
            setPadding(dp(8), dp(4), dp(4), dp(4))
        }
        val title = TextView(this).apply {
            text = "Adopt Me • Calculadora"
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setPadding(dp(6), 0, dp(4), 0)
        }
        val minimize = Button(this).apply {
            text = "—"
            setOnClickListener { hidePanel() }
        }
        val close = Button(this).apply {
            text = "✕"
            setOnClickListener { removePanel() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        bar.addView(minimize, LinearLayout.LayoutParams(dp(48), dp(42)))
        bar.addView(close, LinearLayout.LayoutParams(dp(48), dp(42)))
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(48)))

        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(false)
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        CookieManager.getInstance().setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        }
        web.loadUrl(CALCULATOR_URL)
        webView = web
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        panelParams = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            (resources.displayMetrics.heightPixels * 0.68f).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        panel = root
        try { wm.addView(root, panelParams) } catch (e: Exception) {
            panel = null
            Toast.makeText(this, "Não foi possível abrir o painel. Confira a permissão de sobreposição.", Toast.LENGTH_LONG).show()
        }
    }

    private fun hidePanel() {
        panel?.let { view ->
            try { wm.removeView(view) } catch (_: Exception) {}
        }
        panel = null
        panelParams = null
        // Mantém o WebView/cookies no Android; ao reabrir, a página é carregada novamente.
        webView?.destroy()
        webView = null
    }

    private fun removePanel() {
        hidePanel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Bolha Adopt Me", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Mantém a bolha flutuante ativa enquanto você joga." }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder
            .setContentTitle("Adopt Me Flutuante")
            .setContentText("Bolha ativa. Toque nela para abrir a calculadora.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
