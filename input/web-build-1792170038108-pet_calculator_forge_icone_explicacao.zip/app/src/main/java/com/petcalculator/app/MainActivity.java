package com.petcalculator.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int OVERLAY_REQUEST = 4107;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xFF101A2B);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        if (savedInstanceState == null) {
            webView.loadUrl("https://petsadoptme.netlify.app/");
        } else {
            webView.restoreState(savedInstanceState);
        }
        explainOverlayPermissionIfNeeded();
    }

    private void explainOverlayPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Ative o botão flutuante")
                    .setMessage("Para que você tenha acesso ao botão flutuante no Roblox e calcular os valores dos pets, será necessário ativar a sobreposição do aplicativo.\n\nSiga estes passos:\n1. Toque em “Ativar sobreposição”.\n2. Nas configurações do Android, encontre “Pet Calculator”.\n3. Ative “Permitir sobreposição a outros apps” (ou “Aparecer sobre outros apps”).\n4. Volte para a Pet Calculator. A bolinha com o ícone do app ficará disponível sobre o Roblox.\n\nEssa permissão permite que o botão apareça por cima de outros aplicativos.")
                    .setPositiveButton("Ativar sobreposição", (dialog, which) -> {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, OVERLAY_REQUEST);
                    })
                    .setNegativeButton("Agora não", (dialog, which) -> dialog.dismiss())
                    .setCancelable(true)
                    .show();
        } else {
            startBubbleService();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            startBubbleService();
        }
    }

    private void startBubbleService() {
        Intent intent = new Intent(this, FloatingBubbleService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else moveTaskToBack(true);
    }
}
