package br.com.motoboycontrol;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private Button button(String text, Runnable action) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0, dp(6), 0, dp(6)); b.setLayoutParams(p); return b;
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(24), dp(22), dp(22)); root.setBackgroundColor(Color.rgb(246,248,252));
        TextView title = new TextView(this); title.setText("Trava Tela"); title.setTextSize(27); title.setTextColor(Color.rgb(16,24,40)); title.setGravity(Gravity.CENTER_VERTICAL); root.addView(title);
        TextView intro = new TextView(this); intro.setText("Use o botão flutuante com o ícone do aplicativo para ativar o bloqueio de qualquer tela. Arraste a bolha para posicioná-la. Configure os pontos de toque opcionais abaixo."); intro.setTextSize(16); intro.setTextColor(Color.rgb(71,84,103)); intro.setPadding(0,dp(12),0,dp(14)); root.addView(intro);
        root.addView(button("1 · Ativar serviço de acessibilidade", () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("2 · Abrir configuração dos marcadores", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_CONFIGURE); startService(i); finish(); }));
        root.addView(button("3 · Ativar modo invisível (ou use a bolha flutuante)", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_ACTIVATE); startService(i); }));
        root.addView(button("Desativar modo invisível", () -> { Intent i = new Intent(this, ControlAccessibilityService.class); i.setAction(ControlAccessibilityService.ACTION_DEACTIVATE); startService(i); }));
        root.addView(button("Testar Lock Task (fixar este app)", () -> {
            try {
                startLockTask();
                android.widget.Toast.makeText(this, "Solicitação de fixação enviada. Se o Android mostrar uma confirmação, leia e confirme. Isso fixa esta tela do Trava Tela, não garante bloquear a barra sobre outros apps.", android.widget.Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                android.widget.Toast.makeText(this, "O Android não permitiu iniciar Lock Task: " + e.getClass().getSimpleName(), android.widget.Toast.LENGTH_LONG).show();
            }
        }));
        root.addView(button("Sair do Lock Task", () -> {
            try { stopLockTask(); android.widget.Toast.makeText(this, "Solicitação para sair do Lock Task enviada.", android.widget.Toast.LENGTH_SHORT).show(); }
            catch (Exception e) { android.widget.Toast.makeText(this, "Não foi possível sair: " + e.getClass().getSimpleName(), android.widget.Toast.LENGTH_LONG).show(); }
        }));
        TextView note = new TextView(this); note.setText("Importante: Lock Task iniciado por um app comum pode virar apenas Fixação de tela, com confirmação e possibilidade de saída pelo usuário. Este teste fixa a tela do próprio Trava Tela; não transforma a bolha flutuante em um bloqueio total sobre Roblox ou outros apps. O bloqueio completo da barra exige gerenciamento do dispositivo (Device Owner) e lista de permissões Lock Task. O botão Power é experimental. Para sair da sobreposição, use Volume + e Volume − juntos por cerca de 2 segundos ou abra o Trava Tela e toque em Desativar. Teste parado, nunca pilotando."); note.setTextSize(13); note.setTextColor(Color.rgb(102,112,133)); note.setPadding(0,dp(18),0,0); root.addView(note);
        setContentView(root);
    }
}
